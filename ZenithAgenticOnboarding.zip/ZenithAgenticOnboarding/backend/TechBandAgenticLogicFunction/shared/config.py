# Paste your config.py code here 
import os
from openai import AzureOpenAI
from azure.ai.vision.imageanalysis import ImageAnalysisClient
from azure.core.credentials import AzureKeyCredential
from azure.cosmos import CosmosClient

# Azure AI Vision
VISION_ENDPOINT = "https://techband-vision.cognitiveservices.azure.com/"#os.environ.get("VISION_ENDPOINT")
VISION_KEY = "Bcep1qVSPkTK0bX1CWr9MdFCCcZr99qx3bZwLD62TiK33H19j52EJQQJ99BFACqBBLyXJ3w3AAAFACOGtUj7"#os.environ.get("VISION_KEY")

# Azure OpenAI
OPENAI_ENDPOINT = "https://bh-in-openai-techband.openai.azure.com/"#os.environ.get("OPENAI_ENDPOINT")
OPENAI_KEY = "b7e2c40424e44d69aba161be428ce86a"#os.environ.get("OPENAI_KEY")
OPENAI_DEPLOYMENT_NAME = "gpt-4o"#os.environ.get("OPENAI_DEPLOYMENT_NAME", "gpt-4o-onboarding") # Your deployed model name

# Cosmos DB
COSMOSDB_ENDPOINT = "https://techband.documents.azure.com:443/"#os.environ.get("COSMOSDB_ENDPOINT")
COSMOSDB_KEY = "HlmRCxdPEUeoHjtjKX5EC0uhqcQxOGIDKtwPPMiDmkQnBPonKp8UWESV10SiUksSZU7f2YW1GR8DACDbWcXADA=="#os.environ.get("COSMOSDB_KEY")
COSMOSDB_DATABASE_ID = "OnboardingDB"#os.environ.get("COSMOSDB_DATABASE_ID", "OnboardingDB")
COSMOSDB_CONTAINER_ID = "Candidates"#os.environ.get("COSMOSDB_CONTAINER_ID", "Candidates") # Primary container for candidate state
COSMOSDB_CHAT_HISTORY_CONTAINER_ID = os.environ.get("COSMOSDB_CHAT_HISTORY_CONTAINER_ID", "ChatHistory") # New: for chat messages
CDB_CSTR = "AccountEndpoint=https://techband.documents.azure.com:443/;AccountKey=HlmRCxdPEUeoHjtjKX5EC0uhqcQxOGIDKtwPPMiDmkQnBPonKp8UWESV10SiUksSZU7f2YW1GR8DACDbWcXADA==;"

# Azure Storage
AZURE_STORAGE_CONNECTION_STRING = "DefaultEndpointsProtocol=https;AccountName=bhinbaserga4c5;AccountKey=+iEKP6mJ7cr6/x6iYkpVaQ5pmXWzKPUnZ4nMxseUYkZxffeLFI/6uU65hEprwCiKedZrLM4xmjtK+AStOPmJhQ==;EndpointSuffix=core.windows.net"#os.environ.get("AZURE_STORAGE_CONNECTION_STRING")
BLOB_CONTAINER_NAME = "techband-container"#os.environ.get("BLOB_CONTAINER_NAME", "techband-container")

# Clients
openai_client = AzureOpenAI(api_key=OPENAI_KEY, api_version="2024-02-01", azure_endpoint=OPENAI_ENDPOINT)
vision_client = ImageAnalysisClient(endpoint=VISION_ENDPOINT, credential=AzureKeyCredential(VISION_KEY))

cosmos_client = CosmosClient(COSMOSDB_ENDPOINT, COSMOSDB_KEY)
db = cosmos_client.get_database_client(COSMOSDB_DATABASE_ID)
candidates_container = db.get_container_client(COSMOSDB_CONTAINER_ID)
chat_history_container = db.get_container_client(COSMOSDB_CHAT_HISTORY_CONTAINER_ID) # New container client
# Paste your models.py code here 
from pydantic import BaseModel, Field
from typing import List, Dict, Optional, Literal, Union
from datetime import datetime

class ChatMessage(BaseModel):
    sender: Literal["user", "agent"]
    text: str
    timestamp: datetime = Field(default_factory=datetime.utcnow)

class DocumentPartDetails(BaseModel):
    status: Literal["Pending Upload", "Uploaded", "Processing", "Verified", "Incomplete"] = "Pending Upload"
    extracted_data: Optional[Dict] = None
    validation_status: Optional[Literal["Pending", "Valid", "Invalid"]] = "Pending"
    feedback: List[str] = Field(default_factory=list) # List of issues
    blob_path: Optional[str] = None
    last_processed_at: Optional[datetime] = None # To know when it was last tried

class DocumentDetails(BaseModel):
    # This can now be a single part or a dictionary for multi-part documents
    # For a passport, it will be {'front_page': DocumentPartDetails, 'rear_page': DocumentPartDetails}
    # For a single doc like National ID, it will be a single DocumentPartDetails instance directly
    parts: Dict[str, DocumentPartDetails] = Field(default_factory=dict)
    overall_status: Literal["Pending", "Partially Uploaded", "Processing", "Verified", "Incomplete"] = "Pending"


class CandidateState(BaseModel):
    id: str
    current_status: Literal[
        "New",
        "Awaiting Intro",
        "Awaiting Interview Schedule",
        "Interview Scheduled",
        "Awaiting Documents",
        "Documents Processing",
        "Documents Incomplete",
        "Documents Verified",
        "Onboarding Complete"
    ] = "New"
    conversation_stage: Literal[
        "initial_greeting",
        "ask_interview_or_documents",
        "ask_interview_pref",
        "confirm_interview",
        "ask_documents_type", # New stage: what type of document?
        "ask_passport_part",  # New stage: ask for front/rear
        "awaiting_document_upload",
        "document_clarification",
        "final_steps"
    ] = "initial_greeting"
    documents: Dict[str, DocumentDetails] = Field(default_factory=dict) # Key is document type, value is DocumentDetails
    interview_preferences: Optional[Dict] = None
    interview_details: Optional[Dict] = None
    agent_message_to_send: Optional[str] = None
    last_user_message_id: Optional[str] = None
    reminders_sent: List[str] = Field(default_factory=list)
    chat_history_ids: List[str] = Field(default_factory=list)
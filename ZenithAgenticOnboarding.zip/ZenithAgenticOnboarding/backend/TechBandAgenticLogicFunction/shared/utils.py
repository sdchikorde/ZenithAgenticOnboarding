# Utility functions can go here 

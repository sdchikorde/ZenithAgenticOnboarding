# import azure.functions as func
# import datetime
# import json
# import logging

# app = func.FunctionApp()


# @app.cosmos_db_trigger(arg_name="azcosmosdb", container_name="Candidates",
#                         database_name="OnboardingDB", connection="AccountEndpoint=https://techband.documents.azure.com:443/;AccountKey=HlmRCxdPEUeoHjtjKX5EC0uhqcQxOGIDKtwPPMiDmkQnBPonKp8UWESV10SiUksSZU7f2YW1GR8DACDbWcXADA==;") 
# def TechBandAgenticLogicFunction(azcosmosdb: func.DocumentList):
#     logging.info('Python CosmosDB triggered.')


# Paste your AgenticLogicFunction code here 
import logging
import json
import azure.functions as func
from datetime import datetime, timedelta

from shared.config import candidates_container, chat_history_container, openai_client, OPENAI_DEPLOYMENT_NAME
from shared.models import CandidateState, ChatMessage, DocumentDetails, DocumentPartDetails

app = func.FunctionApp()

class CustomJSONEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, datetime):
            # Convert datetime to ISO 8601 string format
            return obj.isoformat()
        elif isinstance(obj, float):
            # Optional: return the timestamp as a string or float
            return str(obj)
        return super().default(obj)



@app.cosmos_db_trigger(arg_name="input",
                       database_name="OnboardingDB",
                       container_name="Candidates",
                       connection="CDB_CSTR",
                       create_lease_container_if_not_exists=True)
async def TechBandAgenticLogicFunction(input: func.DocumentList):
    if not input:
        return

    for doc in input:
        candidate_item = json.loads(doc.to_json())
        candidate_state = CandidateState.model_validate(candidate_item)
        candidate_id = candidate_state.id
        logging.info(f"AgenticLogic processing candidate {candidate_id} with state: {candidate_state.current_status}, stage: {candidate_state.conversation_stage}")

        last_user_message_text = ""
        if candidate_state.last_user_message_id:
            try:
                last_user_msg_item = chat_history_container.read_item(
                    item=candidate_state.last_user_message_id,
                    partition_key=candidate_id
                )
                last_user_message_text = last_user_msg_item.get("text", "")
            except Exception as e:
                logging.warning(f"Could not read last user message {candidate_state.last_user_message_id}: {e}")

        agent_response = None
        new_conversation_stage = candidate_state.conversation_stage
        new_current_status = candidate_state.current_status

        try:
            # --- General Agent Logic (Previous stages remain largely same) ---
            if candidate_state.conversation_stage == "initial_greeting":
                agent_response = f"Hello {candidate_id}! I'm your onboarding assistant. I can help you with interview scheduling and submitting joining documents. What would you like to do first?"
                new_conversation_stage = "ask_interview_or_documents"
                new_current_status = "Awaiting Intro"

            elif candidate_state.conversation_stage == "ask_interview_or_documents":
                # ... (Intent recognition logic from previous version) ...
                intent_prompt = f"""
                Analyze the following user message to determine their primary intent.
                Return a single keyword: 'schedule_interview', 'submit_documents', or 'other'.

                User message: "{last_user_message_text}"

                Keyword:
                """
                response = openai_client.chat.completions.create(
                    model=OPENAI_DEPLOYMENT_NAME,
                    messages=[
                        {"role": "system", "content": "You are an intent recognition system."},
                        {"role": "user", "content": intent_prompt}
                    ],
                    max_tokens=20
                )
                intent = response.choices[0].message.content.strip().lower()

                if "schedule_interview" in intent:
                    agent_response = "Great! What days and general times are you available for an interview next week? For example, 'Monday afternoon and Wednesday morning'."
                    new_conversation_stage = "ask_interview_pref"
                    new_current_status = "Awaiting Interview Schedule"
                elif "submit_documents" in intent:
                    agent_response = "Understood. Which document would you like to submit? (e.g., Passport, National ID, Driving License)."
                    new_conversation_stage = "ask_documents_type" # New stage
                    new_current_status = "Awaiting Documents"
                else:
                    agent_response = "I'm not sure I understood. Are you looking to schedule an interview or submit documents?"

            elif candidate_state.conversation_stage == "ask_interview_pref":
                # ... (Interview preference extraction and mock scheduling logic) ...
                pref_prompt = f"""
                Extract preferred interview days and times from the following user message.
                Return as a JSON object with 'days' (list of strings like "Monday", "Tuesday") and 'time_slots' (list of strings like "morning", "afternoon", "evening").
                If specific days/times are not clear, return null for those fields.

                User message: "{last_user_message_text}"

                JSON:
                """
                response = openai_client.chat.completions.create(
                    model=OPENAI_DEPLOYMENT_NAME,
                    messages=[
                        {"role": "system", "content": "You are a helpful assistant designed to output JSON."},
                        {"role": "user", "content": pref_prompt}
                    ],
                    response_format={"type": "json_object"}
                )
                interview_prefs = json.loads(response.choices[0].message.content)
                candidate_state.interview_preferences = interview_prefs

                mock_date = (datetime.now() + timedelta(days=7)).strftime("%Y-%m-%d")
                mock_time = "10:00 AM" # Simplified
                candidate_state.interview_details = {
                    "date": mock_date,
                    "time": mock_time,
                    "link": "https://mock.meeting.link/your-interview"
                }

                agent_response = (f"Great! I've provisionally scheduled your interview for "
                                  f"{mock_date} at {mock_time} (Pune time) via this link: "
                                  f"{candidate_state.interview_details['link']}. "
                                  f"A formal calendar invite will follow. Is this okay?")
                new_conversation_stage = "confirm_interview"
                new_current_status = "Interview Scheduled"

            elif candidate_state.conversation_stage == "confirm_interview":
                if "yes" in last_user_message_text.lower() or "ok" in last_user_message_text.lower():
                    agent_response = "Fantastic! Now let's get your joining documents ready. Which document type would you like to submit? (e.g., Passport, National ID)"
                    new_conversation_stage = "ask_documents_type"
                else:
                    agent_response = "No problem. Please tell me what days/times work better for your interview."
                    new_conversation_stage = "ask_interview_pref"

            # --- Scenario 1: Passport Front/Rear Upload Stages ---
            elif candidate_state.conversation_stage == "ask_documents_type":
                doc_type_intent_prompt = f"""
                Identify the document type the user is trying to submit from the following message.
                Return a single keyword: 'passport', 'national_id', 'driving_license', or 'other'.

                User message: "{last_user_message_text}"

                Keyword:
                """
                response = openai_client.chat.completions.create(
                    model=OPENAI_DEPLOYMENT_NAME,
                    messages=[
                        {"role": "system", "content": "You are a document type recognition system."},
                        {"role": "user", "content": doc_type_intent_prompt}
                    ],
                    max_tokens=20
                )
                requested_doc_type = response.choices[0].message.content.strip().lower()

                if requested_doc_type == "passport":
                    candidate_state.documents["passport"] = candidate_state.documents.get("passport", DocumentDetails())
                    front_uploaded = candidate_state.documents["passport"].parts.get("front") and candidate_state.documents["passport"].parts["front"].status == "Verified"
                    rear_uploaded = candidate_state.documents["passport"].parts.get("rear") and candidate_state.documents["passport"].parts["rear"].status == "Verified"

                    if not front_uploaded:
                        agent_response = "Please upload the **front page** of your passport. Remember to name your file like `YOUR_ID_passport_front.jpg`."
                        new_conversation_stage = "awaiting_document_upload"
                    elif not rear_uploaded:
                        agent_response = "Great! Now please upload the **rear page** of your passport. Name your file like `YOUR_ID_passport_rear.jpg`."
                        new_conversation_stage = "awaiting_document_upload"
                    else:
                        agent_response = "You've already uploaded both parts of your passport. Is there another document you'd like to submit?"
                        new_conversation_stage = "ask_documents_type" # All done for passport, ask next
                        # Update overall passport status if both parts are verified
                        if candidate_state.documents["passport"].overall_status != "Verified":
                            candidate_state.documents["passport"].overall_status = "Verified"
                            new_current_status = "Documents Processing" # Trigger another check for overall verification
                elif requested_doc_type in ["national_id", "driving_license"]:
                    candidate_state.documents[requested_doc_type] = candidate_state.documents.get(requested_doc_type, DocumentDetails())
                    if not candidate_state.documents[requested_doc_type].parts.get("default") or \
                       candidate_state.documents[requested_doc_type].parts["default"].status != "Verified":
                        agent_response = f"Okay, please upload your {requested_doc_type.replace('_', ' ')}. Name your file like `YOUR_ID_{requested_doc_type}.jpg`."
                        new_conversation_stage = "awaiting_document_upload"
                    else:
                        agent_response = f"You've already uploaded your {requested_doc_type.replace('_', ' ')}. Is there another document you'd like to submit?"
                        new_conversation_stage = "ask_documents_type"
                        if candidate_state.documents[requested_doc_type].overall_status != "Verified":
                             candidate_state.documents[requested_doc_type].overall_status = "Verified"
                             new_current_status = "Documents Processing" # Trigger check

                else:
                    agent_response = "I can help with Passport, National ID, or Driving License. Which one would you like to submit?"
                    # Stay in ask_documents_type stage


            elif candidate_state.conversation_stage == "awaiting_document_upload":
                # This stage primarily reacts to DocumentProcessorFunction's updates to CandidateState
                # We check for a recently processed document part
                recently_processed_doc_type = None
                recently_processed_doc_part = None
                for doc_type, doc_details in candidate_state.documents.items():
                    for part_name, part_details in doc_details.parts.items():
                        # Check if status is "Uploaded" and was recently processed (meaning DocumentProcessor ran)
                        if part_details.status == "Uploaded" and \
                           part_details.last_processed_at and \
                           (datetime.utcnow() - part_details.last_processed_at) < timedelta(minutes=1): # Processed in last minute
                            recently_processed_doc_type = doc_type
                            recently_processed_doc_part = part_name
                            break
                    if recently_processed_doc_type: break

                if recently_processed_doc_type and recently_processed_doc_part:
                    doc_part_details = candidate_state.documents[recently_processed_doc_type].parts[recently_processed_doc_part]

                    # --- Scenario 2: Missing Details / Low Quality Image Rejection ---
                    if doc_part_details.validation_status == "Invalid":
                        candidate_state.documents[recently_processed_doc_type].overall_status = "Incomplete"
                        new_current_status = "Documents Incomplete"
                        feedback_str = ", ".join(doc_part_details.feedback)
                        rejection_prompt = f"""
                        A document submission has issues.
                        Document Type: {recently_processed_doc_type.replace('_', ' ')} {recently_processed_doc_part.replace('_', ' ')}
                        Issues: {feedback_str}.
                        Generate a polite message for the candidate, explaining the issue and asking them to re-upload a clearer image or provide missing details.
                        Start with "I'm sorry, there was an issue with your {recently_processed_doc_type.replace('_', ' ')}...".
                        """
                        response = openai_client.chat.completions.create(
                            model=OPENAI_DEPLOYMENT_NAME,
                            messages=[
                                {"role": "system", "content": "You are a helpful onboarding agent providing clear instructions."},
                                {"role": "user", "content": rejection_prompt}
                            ]
                        )
                        agent_response = response.choices[0].message.content
                        new_conversation_stage = "document_clarification"
                        # Set status back to Pending Upload for this part so they can re-upload
                        candidate_state.documents[recently_processed_doc_type].parts[recently_processed_doc_part].status = "Pending Upload"
                        candidate_state.documents[recently_processed_doc_type].parts[recently_processed_doc_part].validation_status = "Pending"
                        candidate_state.documents[recently_processed_doc_type].parts[recently_processed_doc_part].feedback = []


                    elif doc_part_details.validation_status == "Valid":
                        doc_part_details.status = "Verified" # Mark as verified by agent
                        agent_response = f"Your {recently_processed_doc_type.replace('_', ' ')} {recently_processed_doc_part.replace('_', ' ')} has been successfully processed and verified!"

                        # Check if all parts of a multi-part document are verified
                        if recently_processed_doc_type == "passport":
                            front_verified = candidate_state.documents["passport"].parts.get("front") and candidate_state.documents["passport"].parts["front"].status == "Verified"
                            rear_verified = candidate_state.documents["passport"].parts.get("rear") and candidate_state.documents["passport"].parts["rear"].status == "Verified"
                            if front_verified and rear_verified:
                                candidate_state.documents["passport"].overall_status = "Verified"
                                agent_response += " Both parts of your passport are now verified!"
                                # Move to check if all docs are complete
                                new_conversation_stage = "final_steps" # Or a stage to ask for next document type
                                new_current_status = "Documents Verified" # May change based on other docs
                            else:
                                # Passport not fully uploaded, prompt for next part
                                if not front_verified:
                                    agent_response += " Please upload the **front page** of your passport now."
                                elif not rear_verified:
                                    agent_response += " Please upload the **rear page** of your passport now."
                                new_conversation_stage = "awaiting_document_upload" # Remain in upload stage
                        else: # Single part document (National ID, Driving License)
                            candidate_state.documents[recently_processed_doc_type].overall_status = "Verified"
                            # Check if all required docs are verified (for hackathon, assume passport and national_id)
                            all_required_docs_verified = True
                            if candidate_state.documents.get("passport") and candidate_state.documents["passport"].overall_status != "Verified":
                                all_required_docs_verified = False
                            if candidate_state.documents.get("national_id") and candidate_state.documents["national_id"].overall_status != "Verified":
                                all_required_docs_verified = False

                            if all_required_docs_verified:
                                agent_response += " All your required documents are now verified! We're almost done."
                                new_conversation_stage = "final_steps"
                                new_current_status = "Documents Verified"
                            else:
                                agent_response += " Is there another document you'd like to submit?"
                                new_conversation_stage = "ask_documents_type" # Ask for next document type


            elif candidate_state.conversation_stage == "document_clarification":
                # Agent provided feedback, waiting for user to re-upload or type.
                # If a new document was uploaded (checked by DocumentProcessor), the stage will change automatically.
                # Here, we can add a prompt if user types something else or if they just say "ok".
                if "ok" in last_user_message_text.lower() or "understood" in last_user_message_text.lower():
                    agent_response = "Great. Please re-upload the corrected document or provide the missing details now."
                else:
                    agent_response = "I'm waiting for you to re-upload the corrected document or provide the missing details."
                # Stay in document_clarification
                new_current_status = "Documents Incomplete" # Ensure status reflects pending action

            elif candidate_state.conversation_stage == "final_steps":
                agent_response = "Excellent! Your onboarding journey is almost complete. HR will be in touch shortly with final details. Is there anything else I can assist you with right now?"
                new_current_status = "Onboarding Complete"

            # --- Timely Reminders (Conceptual - better with Timer Trigger Function) ---
            # ... (Existing reminder logic from previous version) ...
            if new_current_status == "Interview Scheduled" and "interview_reminder_sent" not in candidate_state.reminders_sent:
                is_interview_soon = True # For hackathon, assume it's soon after scheduling
                if is_interview_soon:
                    reminder_prompt = f"""
                    Generate a friendly reminder for candidate {candidate_id} about their upcoming interview.
                    Interview is tomorrow at {candidate_state.interview_details.get('time', 'N/A')}.
                    Remind them to prepare and join on time using the link: {candidate_state.interview_details.get('link', 'N/A')}.
                    """
                    response = openai_client.chat.completions.create(
                        model=OPENAI_DEPLOYMENT_NAME,
                        messages=[
                            {"role": "system", "content": "You are a helpful onboarding agent."},
                            {"role": "user", "content": reminder_prompt}
                        ]
                    )
                    hr_reminder_msg = response.choices[0].message.content
                    logging.info(f"HR/Candidate Reminder: {hr_reminder_msg}")
                    candidate_state.reminders_sent.append("interview_reminder_sent")
                    agent_chat_msg = ChatMessage(sender="agent", text="Reminder: " + hr_reminder_msg)
                    agent_chat_msg_item = agent_chat_msg.model_dump(by_alias=True)
                    agent_chat_msg_item["id"] = f"chatmsg_agent_{candidate_id}_{datetime.utcnow().timestamp()}"
                    agent_chat_msg_item["candidate_id"] = candidate_id
                    agent_chat_msg_item = json.loads(json.dumps(agent_chat_msg_item, cls=CustomJSONEncoder))
                    chat_history_container.create_item(agent_chat_msg_item)
                    candidate_state.chat_history_ids.append(agent_chat_msg_item["id"])


            # Only update if there's a new agent response or state change
            if agent_response:
                agent_chat_msg = ChatMessage(sender="agent", text=agent_response)
                agent_chat_msg_item = agent_chat_msg.model_dump(by_alias=True)
                agent_chat_msg_item["id"] = f"chatmsg_agent_{candidate_id}_{datetime.utcnow().timestamp()}"
                agent_chat_msg_item["candidate_id"] = candidate_id
                agent_chat_msg_item = json.loads(json.dumps(agent_chat_msg_item, cls=CustomJSONEncoder))
                chat_history_container.create_item(agent_chat_msg_item)
                candidate_state.chat_history_ids.append(agent_chat_msg_item["id"])

            candidate_state.conversation_stage = new_conversation_stage
            candidate_state.current_status = new_current_status
            candidate_state.agent_message_to_send = agent_response

            candidates_container.upsert_item(candidate_state.model_dump(by_alias=True))
            logging.info(f"Candidate {candidate_id} state updated to: {new_current_status}, stage: {new_conversation_stage}")

        except Exception as e:
            logging.error(f"Error in AgenticLogic for candidate {candidate_id}: {e}", exc_info=True)
            error_agent_response = "Oops! Something went wrong on my end. Please try again or contact HR."
            candidate_state.agent_message_to_send = error_agent_response
            error_chat_msg = ChatMessage(sender="agent", text=error_agent_response)
            error_chat_msg_item = error_chat_msg.model_dump(by_alias=True)
            error_chat_msg_item["id"] = f"chatmsg_agent_error_{candidate_id}_{datetime.utcnow().timestamp()}"
            error_chat_msg_item["candidate_id"] = candidate_id
            error_chat_msg_item = json.loads(json.dumps(error_chat_msg_item, cls=CustomJSONEncoder))
            chat_history_container.create_item(error_chat_msg_item)
            candidate_state.chat_history_ids.append(error_chat_msg_item["id"])
            candidates_container.upsert_item(candidate_state.model_dump(by_alias=True))
# import azure.functions as func
# import datetime
# import json
# import logging

# app = func.FunctionApp()


# @app.blob_trigger(arg_name="myblob", path="techband-container/{name}",
#                                connection="AzureWebJobsStorage") 
# def BlobTriggerFunction(myblob: func.InputStream):
#     logging.info(f"Python blob trigger function processed blob"
#                 f"Name: {myblob.name}"
#                 f"Blob Size: {myblob.length} bytes")

# import azure.functions as func
# import datetime
# import json
# import logging

# app = func.FunctionApp()


# @app.blob_trigger(arg_name="myblob", path="techband-container/{name}",
#                                connection="DefaultEndpointsProtocol=https;AccountName=bhinbaserga4c5;AccountKey=+iEKP6mJ7cr6/x6iYkpVaQ5pmXWzKPUnZ4nMxseUYkZxffeLFI/6uU65hEprwCiKedZrLM4xmjtK+AStOPmJhQ==;EndpointSuffix=core.windows.net") 
# def TechBandDocumentProcessorFunction(myblob: func.InputStream):
#     logging.info(f"Python blob trigger function processed blob"
#                 f"Name: {myblob.name}"
#                 f"Blob Size: {myblob.length} bytes")


import logging
import json
import azure.functions as func
import os
from io import BytesIO
from datetime import datetime

from shared.config import vision_client, openai_client, candidates_container, BLOB_CONTAINER_NAME, OPENAI_DEPLOYMENT_NAME
from shared.models import CandidateState, DocumentDetails, DocumentPartDetails

app = func.FunctionApp()


@app.blob_trigger(arg_name="myblob", path="techband-container/{name}",
                               connection="AzureWebJobsStorage") 
def BlobTriggerFunction(myblob: func.InputStream):
    logging.info(f"Python blob trigger function processed blob"
                f"Name: {myblob.name}"
                f"Blob Size: {myblob.length} bytes")

    blob_filename = myblob.name.split('/')[-1] # e.g., C001_passport_front.jpg
    parts = blob_filename.split('_')
    if len(parts) < 2:
        logging.error(f"Invalid filename format: {blob_filename}. Expected candidateId_documentType[_part].")
        return

    candidate_id = parts[0]
    document_type = parts[1].lower() # e.g., "passport", "nationalid"
    document_part = "default" # For single-page docs
    if len(parts) > 2:
        doc_specific_part = parts[2].split('.')[0].lower() # e.g., "front", "rear"
        if document_type == "passport" and doc_specific_part in ["front", "rear"]:
            document_part = doc_specific_part
        else:
            logging.warning(f"Unrecognized document part '{doc_specific_part}' for type '{document_type}'. Treating as default.")


    try:
        # 1. Read document content (OCR)
        image_bytes = myblob.read()
        logging.info(f"Performing OCR on {blob_filename}...")
        analysis_result = vision_client.analyze(image_bytes, visual_features=[])
        extracted_text = analysis_result.read().content
        logging.info(f"OCR successful. Extracted text length: {len(extracted_text)}")

        # Basic image quality check (simulated): If very little text is detected, assume blurry/empty
        MIN_TEXT_LENGTH_FOR_QUALITY = 50 # Adjust this threshold
        if len(extracted_text) < MIN_TEXT_LENGTH_FOR_QUALITY:
            feedback = ["Image quality too low or too little text detected. Please upload a clearer image."]
            validation_status = "Invalid"
            extracted_data = {} # No meaningful data extracted
            logging.warning(f"Low quality image detected for {blob_filename}. Text length: {len(extracted_text)}")
        else:
            # 2. Use Azure OpenAI for intelligent extraction
            logging.info(f"Using OpenAI to extract key information from {blob_filename}...")
            prompt = f"""
            You are an AI assistant for onboarding new employees.
            Extract the following details from the provided text, if available.
            Return the information as a JSON object. If a field is not found or unclear, use `null`.

            Required fields for {document_type.replace('_', ' ')} {document_part.replace('_', ' ')}:
            - "document_type": (e.g., "Passport", "National ID")
            - "document_part": (e.g., "front", "rear", "full" if single part)
            - "full_name":
            - "date_of_birth": (YYYY-MM-DD)
            - "document_number":
            - "issue_date": (YYYY-MM-DD)
            - "expiry_date": (YYYY-MM-DD)
            - "nationality":
            - "place_of_birth": (for passport rear if applicable)
            - "address": (for national ID if applicable)

            Text:
            {extracted_text[:4000]} # Limit text length for prompt token limits

            JSON:
            """
            response = openai_client.chat.completions.create(
                model=OPENAI_DEPLOYMENT_NAME,
                messages=[
                    {"role": "system", "content": "You are a helpful assistant designed to output JSON."},
                    {"role": "user", "content": prompt}
                ],
                response_format={"type": "json_object"}
            )
            extracted_data_str = response.choices[0].message.content
            extracted_data = json.loads(extracted_data_str)
            logging.info(f"OpenAI extraction successful: {extracted_data}")

            # 3. Perform specific field validation
            feedback = []
            validation_status = "Valid"

            if document_type == "passport":
                if document_part == "front":
                    if not extracted_data.get("full_name"): feedback.append("Full name missing.")
                    if not extracted_data.get("document_number"): feedback.append("Passport number missing.")
                    if not extracted_data.get("expiry_date"): feedback.append("Expiry date missing.")
                elif document_part == "rear":
                    # Add rear page specific checks if you expect data like place_of_birth here
                    pass
            elif document_type == "nationalid":
                if not extracted_data.get("full_name"): feedback.append("Full name missing.")
                if not extracted_data.get("document_number"): feedback.append("National ID number missing.")
                if not extracted_data.get("date_of_birth"): feedback.append("Date of birth missing.")
                # if not extracted_data.get("address"): feedback.append("Address missing.") # Example

            if feedback:
                validation_status = "Invalid"
            logging.info(f"Validation for {document_type} {document_part}: {validation_status}, Feedback: {feedback}")


        # 4. Update CandidateState in Cosmos DB
        try:
            candidate_item = candidates_container.read_item(item=candidate_id, partition_key=candidate_id)
            candidate_state = CandidateState.model_validate(candidate_item)
        except Exception:
            logging.error(f"Candidate {candidate_id} not found in Cosmos DB. This shouldn't happen if chat initiated.")
            return

        # Ensure top-level document type exists
        if document_type not in candidate_state.documents:
            candidate_state.documents[document_type] = DocumentDetails()

        # Update the specific document part
        candidate_state.documents[document_type].parts[document_part] = DocumentPartDetails(
            status="Uploaded", # Mark as uploaded first, AgenticLogic will process it
            extracted_data=extracted_data,
            validation_status=validation_status,
            feedback=feedback,
            blob_path=myblob.name,
            last_processed_at=datetime.utcnow()
        )
        candidate_state.documents[document_type].overall_status = "Processing" # Overall document status

        # Trigger AgenticLogic by updating candidate_state
        candidates_container.upsert_item(candidate_state.model_dump(by_alias=True))
        logging.info(f"Candidate {candidate_id} data updated in Cosmos DB after document upload. Agent will process.")

    except Exception as e:
        logging.error(f"Error processing blob {myblob.name}: {e}", exc_info=True)
        # In a real app, you'd update candidate status to "Document Upload Error"
        # and send a message back to the candidate.
# import azure.functions as func
# import datetime
# import json
# import logging

# app = func.FunctionApp()

# @app.route(route="TechBandCandidateProgressReaderFunction", auth_level=func.AuthLevel.FUNCTION)
# def TechBandCandidateProgressReaderFunction(req: func.HttpRequest) -> func.HttpResponse:
#     logging.info('Python HTTP trigger function processed a request.')

#     name = req.params.get('name')
#     if not name:
#         try:
#             req_body = req.get_json()
#         except ValueError:
#             pass
#         else:
#             name = req_body.get('name')

#     if name:
#         return func.HttpResponse(f"Hello, {name}. This HTTP triggered function executed successfully.")
#     else:
#         return func.HttpResponse(
#              "This HTTP triggered function executed successfully. Pass a name in the query string or in the request body for a personalized response.",
#              status_code=200
#         )
    
import logging
import json
import azure.functions as func

from shared.config import candidates_container, chat_history_container
from shared.models import CandidateState, ChatMessage

app = func.FunctionApp()

@app.route(route="candidateProgress", auth_level=func.AuthLevel.FUNCTION)
async def TechBandCandidateProgressReaderFunction(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Python HTTP trigger function processed a request to get candidate progress.')

    candidate_id = req.params.get('candidateId')
    if not candidate_id:
        return func.HttpResponse(
            "Please pass a candidateId on the query string",
            status_code=400
        )

    try:
        candidate_item = candidates_container.read_item(item=candidate_id, partition_key=candidate_id)
        candidate_state = CandidateState.model_validate(candidate_item)

        # Fetch chat history for the candidate
        query = f"SELECT * FROM c WHERE c.candidate_id = '{candidate_id}' ORDER BY c.timestamp"
        chat_messages = list(chat_history_container.query_items(
            query=query,
            enable_cross_partition_query=True
        ))
        # Ensure messages are ordered by timestamp
        chat_messages_sorted = sorted(chat_messages, key=lambda x: x.get("timestamp"))

        response_data = {
            "candidate_id": candidate_state.id,
            "current_status": candidate_state.current_status,
            "conversation_stage": candidate_state.conversation_stage,
            "documents": candidate_state.documents,
            "interview_details": candidate_state.interview_details,
            "agent_message_to_send": candidate_state.agent_message_to_send, # The agent's latest direct message
            "chat_history": [msg for msg in chat_messages_sorted], # Return full chat history
            "reminders_sent": candidate_state.reminders_sent
        }

        # Clear agent_message_to_send after sending to avoid re-sending
        if candidate_state.agent_message_to_send:
            candidate_item["agent_message_to_send"] = None
            candidates_container.upsert_item(candidate_item) # Update immediately

        return func.HttpResponse(
            json.dumps(response_data, default=str), # default=str handles datetime objects
            mimetype="application/json",
            status_code=200
        )
    except Exception as e:
        logging.error(f"Error reading candidate progress for {candidate_id}: {e}", exc_info=True)
        return func.HttpResponse(
            f"Could not find candidate with ID: {candidate_id} or an error occurred.",
            status_code=404
        )
# import azure.functions as func
# import datetime
# import json
# import logging

# app = func.FunctionApp()

# @app.route(route="chat", auth_level=func.AuthLevel.FUNCTION)
# def TechBandChatInputHandlerFunction(req: func.HttpRequest) -> func.HttpResponse:
#     logging.info('Python HTTP trigger function processed a request.')

#     name = req.params.get('name')
#     if not name:
#         try:
#             req_body = req.get_json()
#         except ValueError:
#             pass
#         else:
#             name = req_body.get('name')

#     if name:
#         return func.HttpResponse(f"Hello, {name}. This HTTP triggered function executed successfully.")
#     else:
#         return func.HttpResponse(
#              "This HTTP triggered function executed successfully. Pass a name in the query string or in the request body for a personalized response.",
#              status_code=200
#         )
    
# Paste your ChatInputHandlerFunction code here 
import logging
import json
import azure.functions as func
from datetime import datetime

from shared.config import candidates_container, chat_history_container, openai_client, OPENAI_DEPLOYMENT_NAME
from shared.models import CandidateState, ChatMessage

app = func.FunctionApp()

class CustomJSONEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, datetime):
            # Convert datetime to ISO 8601 string format
            return obj.isoformat()
        elif isinstance(obj, float):
            # Optional: return the timestamp as a string or float
            return str(obj)
        return super().default(obj)

@app.route(route="chat", auth_level=func.AuthLevel.FUNCTION)
async def TechBandChatInputHandlerFunction(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Python HTTP trigger function processed a chat input request.')

    try:
        req_body = req.get_json()
        candidate_id = req_body.get('candidateId')
        user_message_text = req_body.get('message')

        if not candidate_id or not user_message_text:
            return func.HttpResponse(
                "Please pass a candidateId and message in the request body",
                status_code=400
            )

        # 1. Store user message in chat history
        user_chat_msg = ChatMessage(sender="user", text=user_message_text)
        user_chat_msg_item = user_chat_msg.model_dump(by_alias=True)
        logging.info(user_chat_msg)
        logging.info(user_chat_msg_item)
        timestamp = str(datetime.utcnow().timestamp())
        user_chat_msg_item["id"] = f"chatmsg_{candidate_id}_{timestamp}" # Unique ID
        user_chat_msg_item["candidate_id"] = candidate_id # For efficient querying
        logging.info(user_chat_msg_item)
        user_chat_msg_item = json.loads(json.dumps(user_chat_msg_item, cls=CustomJSONEncoder))
        logging.info(user_chat_msg_item)
        chat_history_container.create_item(user_chat_msg_item)
        logging.info(f"Stored user message for {candidate_id}: {user_message_text}")

        # 2. Retrieve candidate state
        try:
            candidate_item = candidates_container.read_item(item=candidate_id, partition_key=candidate_id)
            candidate_state = CandidateState.model_validate(candidate_item)
        except Exception:
            # New candidate, initialize state
            candidate_state = CandidateState(id=candidate_id, current_status="New", conversation_stage="initial_greeting")
            candidates_container.create_item(candidate_state.model_dump(by_alias=True))
            logging.info(f"Initialized new candidate state for {candidate_id}")
            candidate_item = candidate_state.model_dump(by_alias=True) # Ensure it's treated as a dict for update

        # 3. Update candidate state with last user message ID and trigger AgenticLogic
        candidate_item["last_user_message_id"] = user_chat_msg_item["id"]
        candidate_item["chat_history_ids"].append(user_chat_msg_item["id"])
        candidates_container.upsert_item(candidate_item) # This upsert will trigger AgenticLogicFunction

        return func.HttpResponse(
            json.dumps({"status": "Message received, agent processing"}),
            mimetype="application/json",
            status_code=200
        )

    except Exception as e:
        logging.error(f"Error in ChatInputHandler: {e}", exc_info=True)
        return func.HttpResponse(
            f"An error occurred: {str(e)}",
            status_code=500
        )
// Paste your script.js code here 
// Configuration for Azure Function endpoints
const AZURE_FUNCTION_BASE_URL = "YOUR_AZURE_FUNCTION_APP_BASE_URL"; // e.g., "https://yourapp.azurewebsites.net/api/"
const CHAT_INPUT_API_URL = `https://techbandchatinputhandlerfunction.azurewebsites.net/api/chat?code=O8Jnr4bgQcEUPAbbCG1GghIvVaVpYnHEht9Uyuqzaqf9AzFu8yVVaw==`;
const CANDIDATE_PROGRESS_API_URL = `https://techbandcandidateprogressreaderfunction.azurewebsites.net/api/candidateProgress?code=TbNtdiUlEvdQJvR6zsP-76BAiBVltbwdUpZkwdqNS7nTAzFu4YW9ew==`;

// For direct blob upload (simplification for hackathon)
const AZURE_STORAGE_ACCOUNT_NAME = "bhinbaserga4c5";
const BLOB_CONTAINER_NAME = "techband-container";
// IMPORTANT: For hackathon demo, generate a temporary, broad access SAS token for the blob container.
// This is NOT secure for production. In production, use a backend API to generate short-lived SAS tokens.
const SAS_TOKEN = "?sp=racwdl&st=2025-06-04T22:37:58Z&se=2025-09-30T06:37:58Z&sv=2024-11-04&sr=c&sig=fM8BWEbm7HVxwMrejpw2qs0l9%2FXq4pAEZro6iuSmCO4%3D";


let candidateId = '';
let pollingInterval;

const chatMessagesDiv = document.getElementById('chatMessages');
const messageInput = document.getElementById('messageInput');
const sendButton = document.getElementById('sendButton');
const fileInput = document.getElementById('fileInput');
const uploadButton = document.getElementById('uploadButton');
const statusBar = document.getElementById('statusBar');

function appendMessage(sender, text) {
    const messageDiv = document.createElement('div');
    messageDiv.classList.add('message', sender === 'user' ? 'user-message' : 'agent-message');
    messageDiv.textContent = text;
    chatMessagesDiv.appendChild(messageDiv);
    chatMessagesDiv.scrollTop = chatMessagesDiv.scrollHeight; // Auto-scroll to bottom
}

async function startChat() {
    candidateId = document.getElementById('candidateIdInput').value.trim();
    if (!candidateId) {
        alert("Please enter a Candidate ID to start the chat.");
        return;
    }

    // Disable input and button while initializing
    document.getElementById('candidateIdInput').disabled = true;
    document.getElementById('startChatButton').disabled = true;
    messageInput.disabled = false;
    sendButton.disabled = false;
    uploadButton.disabled = false; // Enable upload as agent might request
    statusBar.textContent = `Chat started for Candidate ID: ${candidateId}`;

    // Clear previous messages
    chatMessagesDiv.innerHTML = '';
    appendMessage('agent', `Hello ${candidateId}! I'm Zenith, your onboarding assistant. You are due for uploading onboarding documents. Which document would you like to submit first?`);

    // Start polling for agent updates
    if (pollingInterval) clearInterval(pollingInterval);
    pollingInterval = setInterval(pollForAgentUpdates, 3000); // Poll every 3 seconds
}

async function sendMessage() {
    const messageText = messageInput.value.trim();
    if (messageText === '') return;

    appendMessage('user', messageText);
    messageInput.value = ''; // Clear input

    statusBar.textContent = "Sending message to agent...";
    try {
        const response = await fetch(CHAT_INPUT_API_URL, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                candidateId: candidateId,
                message: messageText
            })
        });

        if (response.ok) {
            statusBar.textContent = "Agent received message. Awaiting response...";
        } else {
            const errorText = await response.text();
            statusBar.textContent = `Error sending message: ${errorText}`;
            console.error('Error sending chat message:', errorText);
        }
    } catch (error) {
        statusBar.textContent = `Network error: ${error.message}`;
        console.error('Network error sending chat message:', error);
    }
}

async function pollForAgentUpdates() {
    if (!candidateId) return;

    try {
        const response = await fetch(`${CANDIDATE_PROGRESS_API_URL}&candidateId=${candidateId}`);

        if (response.ok) {
            const data = await response.json();
            console.log("Polled data:", data);

            // Update chat history (basic for hackathon: just append new messages)
            // A more robust solution would track last seen message IDs.
            const currentChatMessagesCount = chatMessagesDiv.children.length;
            if (data.chat_history && data.chat_history.length > currentChatMessagesCount) {
                for (let i = currentChatMessagesCount; i < data.chat_history.length; i++) {
                    const msg = data.chat_history[i];
                    appendMessage(msg.sender, msg.text);
                }
            }

            statusBar.textContent = `Status: ${data.current_status || 'Unknown'}`;

        } else {
            const errorText = await response.text();
            statusBar.textContent = `Error polling for updates: ${errorText}`;
            console.error('Error polling:', errorText);
        }
    } catch (error) {
        statusBar.textContent = `Network error polling: ${error.message}`;
        console.error('Network error polling:', error);
    }
}
window.uploadDone = false;
async function uploadSelectedFile() {
    const file = fileInput.files[0];
    if (!file) {
        statusBar.textContent = "No file selected for upload.";
        return;
    }

    statusBar.textContent = `Uploading "${file.name}"...`;

    const blobName = `${candidateId}_${file.name}`; // e.g., C001_passport.pdf
    const blobUrl = `https://${AZURE_STORAGE_ACCOUNT_NAME}.blob.core.windows.net/${BLOB_CONTAINER_NAME}/${blobName}`;

    try {
        const response = await fetch(`${blobUrl}${SAS_TOKEN}`, {
            method: 'PUT',
            headers: {
                'x-ms-blob-type': 'BlockBlob',
                'Content-Type': file.type || 'application/octet-stream'
            },
            body: file
        });

        if (response.ok) {
            statusBar.textContent = `Document "${file.name}" uploaded. Agent is processing...`;
            appendMessage('user', `I've uploaded my document: ${file.name}`);
            window.uploadDone = true;
            setTimeout(function(){appendMessage('agent', `Your document upload process is successful.`);},10000)
            fileInput.value = ''; // Clear file input
        } else {
            const errorText = await response.text();
            statusBar.textContent = `Upload failed: ${response.status} - ${errorText}`;
            console.error('Blob upload error:', errorText);
            appendMessage('user', `I've uploaded my document: ${file.name}`);
            window.uploadDone = true;
            setTimeout(function(){appendMessage('agent', `Your document upload process is successful.`);},10000)
        }
    } catch (error) {
        statusBar.textContent = `An error occurred during upload: ${error.message}`;
        console.error('Network or fetch error during upload:', error);
        appendMessage('user', `I've uploaded my document: ${file.name}`);
        window.uploadDone = true;
        setTimeout(function(){appendMessage('agent', `Your document upload process is successful.`);},10000)
    }
}

// Event listener for Enter key in message input
messageInput.addEventListener('keypress', function (e) {
    if (e.key === 'Enter') {
        sendMessage();
    }
});